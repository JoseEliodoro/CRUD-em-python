# crud
 Criando crud para PI do senac em python
